App = {
  web3Provider: null,
  contracts: {},
  account: '0x0',

  init: function() {
    return App.initWeb3();
  },

  initWeb3: function() {
    if (typeof web3 !== 'undefined') {
      // If a web3 instance is already provided by Meta Mask.
      App.web3Provider = web3.currentProvider;
      web3 = new Web3(web3.currentProvider);
    } else {
      // Specify default instance if no web3 instance provided
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      web3 = new Web3(App.web3Provider);
    }
    return App.initCarContract();
  },

  initContract: function() {
    $.getJSON("Election.json", function(election) {
      // Instantiate a new truffle contract from the artifact
      App.contracts.Election = TruffleContract(election);
      // Connect provider to interact with contract
      App.contracts.Election.setProvider(App.web3Provider);

      return App.render();
    });
  },
  initCarContract: function() {
    $.getJSON("CarContract.json", function(CarContract) {
      // Instantiate a new truffle contract from the artifact
      App.contracts.CarContract = TruffleContract(CarContract);
      // Connect provider to interact with contract
      App.contracts.CarContract.setProvider(App.web3Provider);

      return App.carRender();
    });
  }
  ,
  carContract: function() {
    $.getJSON("CarContract.json", function(CarContract) {
      // Instantiate a new truffle contract from the artifact
      App.contracts.CarContract = TruffleContract(CarContract);
      // Connect provider to interact with contract
      App.contracts.CarContract.setProvider(App.web3Provider);

      return App.carRender();
  });
},
  render: function() {
    var electionInstance;
    var loader = $("#loader");
    var content = $("#content");
  
    loader.show();
    content.hide();
  
    // Load account data
    web3.eth.getCoinbase(function(err, account) {
      if (err === null) {
        App.account = account;
        $("#accountAddress").html("Your Account: " + account);
      }
    });
  
    // Load contract data
    App.contracts.Election.deployed().then(function(instance) {
      electionInstance = instance;
      console.log(electionInstance);
      return electionInstance.candidatesCount();
    }).then(function(candidatesCount) {
      var candidatesResults = $("#candidatesResults");
      candidatesResults.empty();
  
      var candidatesSelect = $('#candidatesSelect');
      candidatesSelect.empty();
  
      for (var i = 1; i <= candidatesCount; i++) {
        electionInstance.candidates(i).then(function(candidate) {
          var id = candidate[0];
          var name = candidate[1];
          var voteCount = candidate[2];
  
          // Render candidate Result
          var candidateTemplate = "<tr><th>" + id + "</th><td>" + name + "</td><td>" + voteCount + "</td></tr>"
          candidatesResults.append(candidateTemplate);
  
          // Render candidate ballot option
          var candidateOption = "<option value='" + id + "' >" + name + "</ option>"
          candidatesSelect.append(candidateOption);
        });
      }
      return electionInstance.voters(App.account);
    }).then(function(hasVoted) {
      // Do not allow a user to vote
      if(hasVoted) {
        $('form').hide();
      }
      loader.hide();
      content.show();
    }).catch(function(error) {
      console.warn(error);
    });
  },

  castVote: function() {
    var candidateId = $('#candidatesSelect').val();
    App.contracts.Election.deployed().then(function(instance) {
      return instance.vote(candidateId, { from: App.account });
    }).then(function(result) {
      // Wait for votes to update
      $("#content").hide();
      $("#loader").show();
    }).catch(function(err) {
      console.error(err);
    });
  },
  carRender: function() {
    var carInstance;
    var loader = $("#loader");
    var content = $("#content");
  
    loader.show();
    content.hide();
  
    // Load account data
    web3.eth.getCoinbase(function(err, account) {
      if (err === null) {
        App.account = account;
        $("#accountAddress").html("Your Account: " + account);
      }
    });
  
    // Load contract data
    App.contracts.CarContract.deployed().then(function(instance) {
      carInstance = instance;

      // var carModel = document.getElementById("carmodel").value;
      // var carYear = document.getElementById("caryear").value;
      // var carPrice = document.getElementById("carprice").value;
      // var carTest = document.getElementById("cartest").value;
      // var carVoted = document.getElementById("carvote").value;

      var carModel = "BMW";
      var carYear = 1994;
      var carPrice = 10;
      var carTest = true;
      var carVoted = true;
      carInstance.addNewCar(carModel, carYear, carPrice, carTest, carVoted);
      console.log( );
    //   return carInstance.carsCount;
    // }).then(function(carsCount) {
    //   var candidatesResults = $("#candidatesResults");
    //   candidatesResults.empty();
  
    //   var candidatesSelect = $('#candidatesSelect');
    //   candidatesSelect.empty();
    //   console.log(carsCount[0]);
    //   for (var i = 1; i <= carsCount; i++) {
    //     carInstance.candidates(i).then(function(candidate) {
    //       var id = candidate[0];
    //       var name = candidate[1];
    //       var voteCount = candidate[2];
  
    //       // Render candidate Result
    //       var candidateTemplate = "<tr><th>" + id + "</th><td>" + name + "</td><td>" + voteCount + "</td></tr>"
    //       candidatesResults.append(candidateTemplate);
  
    //       // Render candidate ballot option
    //       var candidateOption = "<option value='" + id + "' >" + name + "</ option>"
    //       candidatesSelect.append(candidateOption);
    //     });
    //   }
    //  // return carInstance.voters(App.account);
    // });
  });
  },

  carContractData: function(){

    // Load contract data
     App.contracts.CarContract.deployed().then(function(instance) {
       carContractInstace = instance;
       carInstance.addNewCar(carModel, carYear, carPrice, carTest, carVoted);
     
     
    //   return electionInstance.candidatesCount();
    
    var carModel = document.getElementById("carmodel").value;
    var carYear = document.getElementById("caryear").value;
    var carPrice = document.getElementById("carprice").value;
    var carTest = document.getElementById("cartest").value;
    var carVoted = document.getElementById("carvote").value;
    
      console.log(carModel);
      console.log(carYear);
      console.log(carPrice);
      console.log(carTest);
      console.log(carVoted);
   alert(carVoted);
      
    
    
    
    });
  }
},

$(function() {
  $(window).load(function() {
    App.init();
  });
});